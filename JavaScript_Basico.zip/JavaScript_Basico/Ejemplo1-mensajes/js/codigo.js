/*
    En este ejemplo veremos como mostrar mensajes
    desde JavaScript
*/

// Mostrar el mensaje en un cuadro de dialogo del navegador
alert("Bienvenidos al curso de JavaScript!!!");

// Mostrar el mensaje en la pagina web
document.write("<h1>Hola, que tal?</h1>");
document.write("Muy bien");

// Mostrar el mensaje dentro de la caja
document.getElementById("caja").innerHTML = "<h2 style='color:red;'> Estoy aqui </h2>";

// Mostrar el mensaje en la consola del navegador
console.log("Estoy aqui ------- ");